//---------------------------------------------------------------------------

#include <System.hpp>
#pragma hdrstop
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma comment(lib, "shcore")
#pragma comment(lib, "uxtheme")
#pragma comment(lib, "windowscodecs")
//#pragma comment(lib, "VirtualTrees_R")

#pragma argsused
extern "C" int _libmain(unsigned long reason)
{
	return 1;
}
//---------------------------------------------------------------------------
